$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$previous = (Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot 'current-audio.json') | ConvertFrom-Json).Devices |
    Where-Object { $_.IsDefault -and -not $_.IsInput }
if ($previous.Name -notmatch 'Philips SPA3609') { throw '安装前的默认音响与记录不符。' }
foreach ($dll in @('NAudio.Core.dll','NAudio.Wasapi.dll')) {
    [void][Reflection.Assembly]::LoadFrom((Join-Path $root "dist/声桥-实时版/$dll"))
}
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class RestorePlaybackDefault {
    [DllImport("ole32.dll")] static extern int CoCreateInstance(ref Guid cls, IntPtr outer, int context, ref Guid iid, out IntPtr obj);
    [UnmanagedFunctionPointer(CallingConvention.StdCall)]
    delegate int SetDefault(IntPtr obj, [MarshalAs(UnmanagedType.LPWStr)] string endpoint, int role);
    public static void Apply(string id,int role) {
        Guid cls=new Guid("870AF99C-171D-4F9E-AF0D-E63DF40C2BC9"), iid=new Guid("F8679F50-850A-41CF-9C72-430F290290C8");
        IntPtr obj;
        Marshal.ThrowExceptionForHR(CoCreateInstance(ref cls,IntPtr.Zero,1,ref iid,out obj));
        try {
            var call=Marshal.GetDelegateForFunctionPointer<SetDefault>(Marshal.ReadIntPtr(Marshal.ReadIntPtr(obj),13*IntPtr.Size));
            Marshal.ThrowExceptionForHR(call(obj,id,role));
        } finally { Marshal.Release(obj); }
    }
}
'@
$enumerator = [NAudio.CoreAudioApi.MMDeviceEnumerator]::new()
try {
    foreach ($role in @([NAudio.CoreAudioApi.Role]::Multimedia,[NAudio.CoreAudioApi.Role]::Console)) {
        $device = $enumerator.GetDefaultAudioEndpoint([NAudio.CoreAudioApi.DataFlow]::Render,$role)
        try {
            if ($device.FriendlyName -match 'VB-Audio Virtual Cable') { [RestorePlaybackDefault]::Apply($previous.Id,[int]$role) }
        } finally { $device.Dispose() }
        $verified = $enumerator.GetDefaultAudioEndpoint([NAudio.CoreAudioApi.DataFlow]::Render,$role)
        try { Write-Output "$role  $($verified.FriendlyName)" } finally { $verified.Dispose() }
    }
} finally { $enumerator.Dispose() }
